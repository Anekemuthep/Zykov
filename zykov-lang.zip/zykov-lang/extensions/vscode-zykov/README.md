# Zykov Language for VS Code

Syntax highlighting for `.zyk` files.

## Local install

```bash
mkdir -p ~/.vscode/extensions
cp -R extensions/vscode-zykov ~/.vscode/extensions/zykov-language
```

Restart VS Code, open a `.zyk` file, and select the **Zykov Exhibit** theme for the editorial palette.
