#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
EXT_SRC="$ROOT_DIR/extensions/vscode-zykov"
EXT_DEST="$HOME/.vscode/extensions/zykov-language"

if [ ! -d "$EXT_SRC" ]; then
  echo "VS Code extension folder not found:"
  echo "$EXT_SRC"
  exit 1
fi

mkdir -p "$HOME/.vscode/extensions"
rm -rf "$EXT_DEST"
cp -R "$EXT_SRC" "$EXT_DEST"

echo "Zykov VS Code extension installed at:"
echo "$EXT_DEST"
echo ""
echo "Restart VS Code, open a .zyk file, and select the Zykov Exhibit theme if desired."
