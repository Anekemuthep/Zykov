#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DEMO_FILE="$ROOT_DIR/examples/hello.zyk"

if ! command -v code >/dev/null 2>&1; then
  echo "VS Code command 'code' was not found."
  echo "Open this file manually:"
  echo "$DEMO_FILE"
  exit 0
fi

if [ ! -f "$DEMO_FILE" ]; then
  echo "Demo file not found:"
  echo "$DEMO_FILE"
  exit 1
fi

code "$DEMO_FILE"
