#!/usr/bin/env bash
set -e

echo "Checking local CLI syntax..."
node --check bin/zygrafi.js

echo "Generating local highlight demo..."
node bin/zygrafi.js highlight examples/hello.zyk --out examples/local-test.highlight.html

echo "Generating local publish demo..."
node bin/zygrafi.js publish examples/hello.zyk --out examples/local-test.publish.html --no-open

echo "OK."
