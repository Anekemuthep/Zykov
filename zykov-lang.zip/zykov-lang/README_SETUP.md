# Zykov V1 setup

## One-command setup

From this folder:

```bash
./setup.sh
```

This will:

1. install `zygrafi` and `zykov` globally with npm,
2. install the VS Code `.zyk` syntax extension when the `code` command is available,
3. generate a highlight demo,
4. test `publish` and `sculpt`.

## Commands

```bash
zygrafi publish examples/hello.zyk
zygrafi sculpt examples/living-gallery.zyk
zygrafi highlight examples/hello.zyk
```

## VS Code highlight

Manual install:

```bash
./scripts/install-vscode-extension.sh
```

Then restart VS Code, open a `.zyk` file, and optionally choose:

```text
Preferences: Color Theme -> Zykov Exhibit
```

## Open demo in VS Code

```bash
./scripts/open-demo-vscode.sh
```
