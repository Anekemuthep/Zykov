# Zygrafi CLI — V1 Exhibit Card

Compila archivos `.zyk` a galerías semánticas HTML standalone usando el runtime visual más reciente de Zygrafi Studio:

- layouts por sala y por grafo
- `springLayout`, `forceAtlasLayout`, `concentricLayout`, `randomLayout`
- hover atmosférico con depth fog
- grafo vivo con entrada animada y micro-movimiento
- referencias contextuales `[ref:Topic:id]...[/ref]` y `[note:id]...[/note]`
- ficha translúcida adosada
- breadcrumb contextual
- color base `All/Todos` conectado a nodos no categorizados

## Uso

```bash
node bin/zygrafi.js build examples/hello.zyk --no-open
```

Genera:

```txt
examples/hello.build.html
```

## Preview con interfaz de Studio

```bash
node bin/zygrafi.js preview examples/hello.zyk --no-open
```

Genera:

```txt
examples/hello.preview.html
```

## Salida custom

```bash
node bin/zygrafi.js build examples/living-gallery.zyk --out dist/living-gallery.html --no-open
```

## Alias compatible

También puedes usar:

```bash
node bin/zykov.js build examples/hello.zyk --no-open
```

## Instalar localmente como comando

Desde la carpeta del proyecto:

```bash
npm link
zygrafi build examples/living-gallery.zyk --out dist/living-gallery.html
```


## V1 navigation polish

This build includes the V1 reader/navigation refinements:

- dark exhibition-frame output by default in `build` mode
- topic selector and `Intro` button moved to the top navigation beside the room selector
- cleaner reader panel with larger title badges and no `Nodo:` / `Tópico:` prefixes
- slightly larger entry nodes by default for easier hover navigation
- selected nodes use a warm bright gray highlight inspired by late-afternoon light

## Metadata de título

Puedes definir un título público para la página compilada al comienzo del archivo `.zyk`:

```zyk
Title = "Mi Galería Semántica"
```

El CLI usa ese valor para el `<title>` del HTML, el encabezado visible y el alias público de la página. Esta línea se interpreta como metadata del build y no se envía al runtime Zykov.

## Fix V1.1

- Corrige la inicialización de controles de navegación del header en builds standalone.
- Mantiene el render del grafo en `build` y `preview`.
- Agrega soporte para `Title = "..."`.


## V1 Exhibit Card polish

- Build mode uses an exhibition-card typography stack: `MoMA Sans Medium`, `MoMA Sans`, then system grotesk fallbacks.
- Entry titles and body text share the same editorial font family with preserved hierarchy.
- Body text is justified and uses the full reading width.
- Subtle white divider lines frame the reading block above and below.
- Curator accent remains `#626c78` for Intro and selected nodes.
