#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "Zykov / Zygrafi V1 setup"
echo "semantic curatorial publishing language"
echo "---------------------------------------"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is required but was not found."
  echo "Install Node.js first: https://nodejs.org/"
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "npm is required but was not found."
  exit 1
fi

echo ""
echo "1) Installing zygrafi / zykov CLI globally..."

if command -v zygrafi >/dev/null 2>&1; then
  echo "Existing zygrafi command found: $(command -v zygrafi)"
  echo "Refreshing global install from this folder..."
else
  echo "No existing zygrafi command found. Installing..."
fi

npm install -g "$ROOT_DIR"

echo ""
echo "2) Installing VS Code Zykov syntax extension..."

if command -v code >/dev/null 2>&1; then
  VSCODE_EXT_DIR="$HOME/.vscode/extensions/zykov-language"
  mkdir -p "$HOME/.vscode/extensions"
  rm -rf "$VSCODE_EXT_DIR"
  cp -R "$ROOT_DIR/extensions/vscode-zykov" "$VSCODE_EXT_DIR"
  echo "Installed VS Code extension at:"
  echo "$VSCODE_EXT_DIR"
else
  echo "VS Code command 'code' was not found."
  echo "Skipping automatic VS Code extension install."
  echo "Manual install:"
  echo "  mkdir -p ~/.vscode/extensions"
  echo "  cp -R extensions/vscode-zykov ~/.vscode/extensions/zykov-language"
fi

echo ""
echo "3) Generating highlight demo..."

if [ -f "$ROOT_DIR/examples/hello.zyk" ]; then
  zygrafi highlight "$ROOT_DIR/examples/hello.zyk" --out "$ROOT_DIR/examples/hello.highlight.html"
  echo "Created examples/hello.highlight.html"
else
  echo "No examples/hello.zyk found. Skipping highlight demo."
fi

echo ""
echo "4) Checking publish/sculpt commands..."

if [ -f "$ROOT_DIR/examples/hello.zyk" ]; then
  zygrafi publish "$ROOT_DIR/examples/hello.zyk" --out "$ROOT_DIR/examples/hello.publish.html" --no-open
  zygrafi sculpt "$ROOT_DIR/examples/hello.zyk" --out "$ROOT_DIR/examples/hello.sculpt.html" --no-open
  echo "Created examples/hello.publish.html"
  echo "Created examples/hello.sculpt.html"
else
  echo "No examples/hello.zyk found. Skipping publish/sculpt demo."
fi

echo ""
echo "Setup complete."
echo ""
echo "Try:"
echo "  zygrafi publish examples/hello.zyk"
echo "  zygrafi sculpt examples/living-gallery.zyk"
echo "  zygrafi highlight examples/hello.zyk"
echo ""
echo "For VS Code:"
echo "  1. Restart VS Code"
echo "  2. Open a .zyk file"
echo "  3. Optional: Cmd+Shift+P -> Preferences: Color Theme -> Zykov Exhibit"
echo ""
